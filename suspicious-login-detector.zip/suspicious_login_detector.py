import datetime

# Sample login logs (username, IP address, login time)
login_logs = [
    {"user": "alice", "ip": "128.101.101.101", "time": "2025-07-01 10:00:00"},
    {"user": "alice", "ip": "203.0.113.5", "time": "2025-07-01 10:15:00"},
    {"user": "bob", "ip": "203.0.113.5", "time": "2025-07-01 10:30:00"},
    {"user": "bob", "ip": "203.0.113.5", "time": "2025-07-01 12:00:00"},
]

# Mock function to map IPs to countries
def mock_geo_location(ip):
    ip_map = {
        "128.101.101.101": "USA",
        "203.0.113.5": "India",
    }
    return ip_map.get(ip, "Unknown")

# Suspicious activity detector
def detect_suspicious_logins(logs):
    user_activity = {}
    suspicious = []

    for log in logs:
        user = log["user"]
        ip = log["ip"]
        time = datetime.datetime.strptime(log["time"], "%Y-%m-%d %H:%M:%S")
        location = mock_geo_location(ip)

        if user not in user_activity:
            user_activity[user] = []

        for entry in user_activity[user]:
            time_diff = abs((time - entry["time"]).total_seconds() / 60)
            if entry["location"] != location and time_diff < 30:
                suspicious.append({
                    "user": user,
                    "from": entry["location"],
                    "to": location,
                    "time_diff_minutes": time_diff,
                    "timestamp1": entry["time"],
                    "timestamp2": time
                })

        user_activity[user].append({"ip": ip, "location": location, "time": time})

    return suspicious

# Run the detection
result = detect_suspicious_logins(login_logs)

# Print suspicious activity
if result:
    print("Suspicious logins detected:")
    for entry in result:
        print(f"- User: {entry['user']}, Location changed from {entry['from']} to {entry['to']} "
              f"within {entry['time_diff_minutes']} minutes "
              f"({entry['timestamp1']} → {entry['timestamp2']})")
else:
    print("No suspicious activity detected.")
